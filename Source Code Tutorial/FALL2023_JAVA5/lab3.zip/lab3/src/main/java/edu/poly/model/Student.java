package edu.poly.model;

import java.util.List;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Student {
	@NotBlank
	private String name;
	
	@NotBlank
	@Email
	private String email;
	
	@Min(0)
	@Max(10)
	@NotNull
	private Double marks;
	
	@NotNull
	private Boolean gender;
	
	@NotBlank
	private String faculty;
	
	@NotEmpty
	private List<String> hobbies;
}
