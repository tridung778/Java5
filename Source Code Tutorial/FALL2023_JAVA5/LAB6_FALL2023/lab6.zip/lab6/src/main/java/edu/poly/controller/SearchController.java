package edu.poly.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import edu.poly.dao.ProductDAO;

@Controller
public class SearchController {
	
	@Autowired
	ProductDAO proDao;
	
	@GetMapping("/product/search")
	public String search_index(Model model) {
		model.addAttribute("products", proDao.findAll());
		return "search";
	}
	
	@PostMapping("/product/search")
	public String search_price(Model model, @RequestParam("min") Optional<Double> min, @RequestParam("max") Optional<Double> max) {
		
		//Bài 1
//		model.addAttribute("products", proDao.findByPrice(min.orElse(Double.MIN_VALUE), max.orElse(Double.MAX_VALUE)));
		
		//Bài 4
		model.addAttribute("products", proDao.findByPriceBetween(min.orElse(Double.MIN_VALUE), max.orElse(Double.MAX_VALUE)));
		return "search";
	}
}
