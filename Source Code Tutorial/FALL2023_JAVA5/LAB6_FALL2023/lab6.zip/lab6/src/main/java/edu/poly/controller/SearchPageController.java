package edu.poly.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import edu.poly.dao.ProductDAO;
import edu.poly.service.SessionService;

@Controller
public class SearchPageController {
	
	@Autowired
	SessionService session;
	
	@Autowired
	ProductDAO proDao;
	
	@RequestMapping("/product/search-page")
	public String searchPage_index(Model model, @RequestParam("name") Optional<String> name, @RequestParam("p") Optional<Integer> p) {
		String na = name.orElse(session.get("name"));
		session.set("name", na);
		
		//Bài 2
//		model.addAttribute("page", proDao.findByKeywords("%"+na+"%", PageRequest.of(p.orElse(0),3)));
		
		//Bài 5
		model.addAttribute("page", proDao.findAllByNameLike("%"+na+"%", PageRequest.of(p.orElse(0),3)));
		return "search-page";
	}
}
