package com.nhathanh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ps16500VoThanhNhaLab6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
