package com.nhathanh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ps16500VoThanhNhaLab6Application {

	public static void main(String[] args) {
		SpringApplication.run(Ps16500VoThanhNhaLab6Application.class, args);
	}

}
