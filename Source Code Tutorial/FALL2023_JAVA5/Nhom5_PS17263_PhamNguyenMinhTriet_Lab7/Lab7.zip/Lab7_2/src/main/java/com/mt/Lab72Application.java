package com.mt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab72Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab72Application.class, args);
	}

}
