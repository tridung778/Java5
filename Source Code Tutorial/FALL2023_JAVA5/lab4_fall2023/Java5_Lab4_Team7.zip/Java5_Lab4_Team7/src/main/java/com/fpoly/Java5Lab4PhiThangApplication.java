package com.fpoly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java5Lab4PhiThangApplication {

	public static void main(String[] args) {
		SpringApplication.run(Java5Lab4PhiThangApplication.class, args);
	}

}
