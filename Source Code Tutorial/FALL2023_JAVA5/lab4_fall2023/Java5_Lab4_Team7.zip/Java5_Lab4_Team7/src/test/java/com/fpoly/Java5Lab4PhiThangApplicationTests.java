package com.fpoly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Java5Lab4PhiThangApplicationTests {

	@Test
	void contextLoads() {
	}

}
