package com.fpoly.controller.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fpoly.entity.SanPham;
import com.fpoly.service.SanPhamService;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private SanPhamService spService;
	
	// localhost:/admin
	@GetMapping("")
	public String doGetAdmin(Model model) {
		List<SanPham> listSP = spService.findAll();
		model.addAttribute("listSP", listSP);
		return "admin/admin";
	}
	
	// localhost:8080/admin/xoa?masp=...
	@GetMapping("/xoa")
	public String doGetXoa(@RequestParam("masp") String masp, 
			RedirectAttributes redirectAttributes) {
		try {
			spService.delete(masp);
			redirectAttributes.addFlashAttribute("message", "Xoa thanh cong san pham " + masp);
		} catch (Exception ex) {
			ex.printStackTrace();
			redirectAttributes.addFlashAttribute("message", "Xoa that bai san pham " + masp);
		}
		return "redirect:/admin";
	}
	
	// localhost:8080/admin/sua?masp=...
	@GetMapping("/sua")
	public String doGetSua(@RequestParam("masp") String masp, 
			Model model) {
		SanPham sanpham = spService.findByMaSP(masp);
		model.addAttribute("sanpham", sanpham);
		return "admin/edit";
	}
	
	// localhost:8080/admin/sua
	@PostMapping("/sua")
	public String doPostSua(@ModelAttribute("sanpham") SanPham sanpham, 
			RedirectAttributes redirectAttributes) {
		spService.insertOrUpdate(sanpham);
		redirectAttributes.addFlashAttribute("message", "Da cap nhat thanh cong san pham " + sanpham.getTensp());
		return "redirect:/admin";
	}
}
