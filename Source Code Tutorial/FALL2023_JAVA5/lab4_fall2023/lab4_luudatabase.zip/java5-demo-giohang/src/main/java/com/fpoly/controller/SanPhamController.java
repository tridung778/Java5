package com.fpoly.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fpoly.entity.DanhMuc;
import com.fpoly.entity.SanPham;
import com.fpoly.service.DanhMucService;
import com.fpoly.service.SanPhamService;

@Controller
@RequestMapping("/sanpham")
public class SanPhamController {
	
	@Autowired
	private SanPhamService spService;
	
	@Autowired
	private DanhMucService dmService;

	// localhost:8080/sanpham/{maDM}
	@GetMapping("/{maDM}")
	public String doGetSPByMaDM(@PathVariable("maDM") String madm, Model model) {
		List<SanPham> listSP = spService.findByMaDM(madm);
		model.addAttribute("listSP", listSP);
		List<DanhMuc> listDM = dmService.findAll();
		model.addAttribute("listDM", listDM);
		return "danhmuc"; 
	}
	
	// localhost:8080/sanpham?maSP=...
	@GetMapping("")
	public String doGetSPByMaSP(@RequestParam("maSP") String masp, Model model) {
		SanPham sanpham = spService.findByMaSP(masp);
		model.addAttribute("sanpham", sanpham);
		List<DanhMuc> listDM = dmService.findAll();
		model.addAttribute("listDM", listDM);
		return "detail"; 
	}
}
