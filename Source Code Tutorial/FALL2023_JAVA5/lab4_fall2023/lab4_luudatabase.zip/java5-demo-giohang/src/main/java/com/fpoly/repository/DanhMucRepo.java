package com.fpoly.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fpoly.entity.DanhMuc;

public interface DanhMucRepo extends JpaRepository<DanhMuc, String> {

	DanhMuc findByMadm(String madm);
}
