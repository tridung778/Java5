package com.fpoly.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "hoadonchitiet")
@NoArgsConstructor
@AllArgsConstructor
@Data
public class HoaDonChiTiet implements Serializable {

	private static final long serialVersionUID = -2926608517698989155L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "soluong")
	private int soluong;
	
	@Column(name = "gia")
	private double gia;
	
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "mahd", referencedColumnName = "id")
	@JsonIgnoreProperties(value = {"applications", "hibernateLazyInitializer"})
	private HoaDon hoadon;
	
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "masp", referencedColumnName = "masp")
	@JsonIgnoreProperties(value = {"applications", "hibernateLazyInitializer"})
	private SanPham sanpham;
}
