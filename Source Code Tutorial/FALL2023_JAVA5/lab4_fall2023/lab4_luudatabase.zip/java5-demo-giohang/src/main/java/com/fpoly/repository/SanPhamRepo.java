package com.fpoly.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fpoly.entity.SanPham;

public interface SanPhamRepo extends JpaRepository<SanPham, String>{

	List<SanPham> findByDanhmuc_Madm(String madm);
	SanPham findByMasp(String masp);
}
