package com.fpoly.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fpoly.dto.CartDetailDto;
import com.fpoly.dto.CartDto;
import com.fpoly.entity.HoaDon;
import com.fpoly.entity.HoaDonChiTiet;
import com.fpoly.entity.SanPham;
import com.fpoly.entity.User;
import com.fpoly.repository.HoaDonChiTietRepo;
import com.fpoly.repository.HoaDonRepo;
import com.fpoly.repository.SanPhamRepo;
import com.fpoly.repository.UserRepo;

@Service
public class CartService {
	
	@Autowired
	private HoaDonRepo hdRepo;
	
	@Autowired
	private HoaDonChiTietRepo hdctRepo;
	
	@Autowired
	private SanPhamRepo spRepo;
	
	@Autowired
	private UserRepo userRepo;
	
	@Transactional
	public void insertCart(CartDto cart) {
		HoaDon hoadon = mappingDtoToOrderEntity(cart);
		try {
			// insert HoaDon
			HoaDon hdReturn = hdRepo.saveAndFlush(hoadon);
			List<HoaDonChiTiet> listHDCT = mappingDtoToOrderDetailEntity(cart.getDetail(), hdReturn);
			
			// insert HDCT
			listHDCT.forEach(hdct -> {
				hdctRepo.saveAndFlush(hdct);
				
				// update SL cua SP sau khi insert HDCT
				SanPham sp = spRepo.findByMasp(hdct.getSanpham().getMasp());
				int newQuantity = sp.getSoluong() - hdct.getSoluong();
				sp.setSoluong(newQuantity);
				spRepo.saveAndFlush(sp);
			});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public CartDto updateCart(CartDto cart, String masp, int soLuong, boolean isUpdate) {
		SanPham product = spRepo.findByMasp(masp);
		
		HashMap<String, CartDetailDto> cartDetail = cart.getDetail();
		
		if (cartDetail.containsKey(masp)) {
			if (soLuong < 1) {
				cartDetail.remove(masp);
			} else {
				if (isUpdate) {
					cartDetail.get(masp).setSlMua(soLuong);
				} else {
					int slCu = cartDetail.get(masp).getSlMua();
					cartDetail.get(masp).setSlMua(slCu + soLuong);
				}
			}
		} else {
			CartDetailDto cartDetailDto = new CartDetailDto();
			cartDetailDto.setTensp(product.getTensp());
			cartDetailDto.setGiasp(product.getGiasp());
			cartDetailDto.setMasp(product.getMasp());
			cartDetailDto.setHinh(product.getHinh());
			cartDetailDto.setSlMua(soLuong);
			cartDetail.put(masp, cartDetailDto);
		}
		
		cart.setTongsl(this.getTongSL(cart));
		cart.setTongtien(this.getTongTien(cart));
		
		return cart;
	}
	
	public double getTongTien(CartDto cart) {
		HashMap<String, CartDetailDto> cartDetail = cart.getDetail();
		Double tongTien = 0D;
		for (CartDetailDto cartDetailDto : cartDetail.values()) {
			SanPham product = spRepo.findByMasp(cartDetailDto.getMasp());
			tongTien += product.getGiasp() * cartDetailDto.getSlMua();
		}
		return tongTien;
	}
	
	public int getTongSL(CartDto cart) {
		HashMap<String, CartDetailDto> cartDetail = cart.getDetail();
		int tongSL = 0;
		for (CartDetailDto productDto : cartDetail.values()) {
			tongSL += productDto.getSlMua();
		}
		return tongSL;
	}
	
	private HoaDon mappingDtoToOrderEntity(CartDto cartDto) {
		HoaDon hoadon = new HoaDon();
		hoadon.setDiachi(cartDto.getDiachi());
		hoadon.setDienthoai(cartDto.getDienthoai());
		hoadon.setTongtien(cartDto.getTongtien());
		Optional<User> user = userRepo.findById(cartDto.getUserId());
		hoadon.setUser(user.get());
		return hoadon;
	}
	
	private List<HoaDonChiTiet> mappingDtoToOrderDetailEntity(HashMap<String, CartDetailDto> details, HoaDon hoadon) {
		List<HoaDonChiTiet> result = new ArrayList<>();
		details.forEach((key, hdct) -> {
			HoaDonChiTiet hoadonchitiet = new HoaDonChiTiet();
			SanPham sanpham = spRepo.findByMasp(hdct.getMasp());
			hoadonchitiet.setSanpham(sanpham);
			hoadonchitiet.setGia(hdct.getGiasp());
			hoadonchitiet.setSoluong(hdct.getSlMua());
			hoadonchitiet.setHoadon(hoadon);
			result.add(hoadonchitiet);
		});
		return result;
	}
}
