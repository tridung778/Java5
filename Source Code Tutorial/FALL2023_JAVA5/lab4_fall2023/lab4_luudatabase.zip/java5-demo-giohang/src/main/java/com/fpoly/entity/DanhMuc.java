package com.fpoly.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "danhmuc")
@NoArgsConstructor
@AllArgsConstructor
@Data
public class DanhMuc implements Serializable {
	
	private static final long serialVersionUID = 8640752176670851785L;

	@Id
	@Column(name = "madm")
	private String madm;

	@Column(name = "tendanhmuc")
	private String tendanhmuc;
	
	@Column(name = "ghichu")
	private String ghichu;
}
