package com.fpoly.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fpoly.entity.User;

public interface UserRepo extends JpaRepository<User, Integer> {

	User findByUsernameAndPassword(String username, String password);
}
