package com.fpoly.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fpoly.entity.DanhMuc;
import com.fpoly.repository.DanhMucRepo;

@Service
public class DanhMucService {

	@Autowired
	private DanhMucRepo repo;
	
	public List<DanhMuc> findAll() {
		return repo.findAll();
	}
	
	public DanhMuc findByMadm(String madm) {
		return repo.findByMadm(madm);
	}
}
