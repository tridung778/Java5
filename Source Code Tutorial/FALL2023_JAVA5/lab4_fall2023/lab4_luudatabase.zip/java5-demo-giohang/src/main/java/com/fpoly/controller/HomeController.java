package com.fpoly.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fpoly.entity.DanhMuc;
import com.fpoly.entity.SanPham;
import com.fpoly.entity.User;
import com.fpoly.service.DanhMucService;
import com.fpoly.service.SanPhamService;
import com.fpoly.service.UserService;

@Controller
public class HomeController {
	
	@Autowired
	private SanPhamService spService;
	
	@Autowired
	private DanhMucService dmService;
	
	@Autowired
	private UserService userService;
	
	@GetMapping(value = {"/index", "", "/"})
	public String doGetIndex(Model model) {
		List<DanhMuc> listDM = dmService.findAll();
		model.addAttribute("listDM", listDM);
		List<SanPham> listSP = spService.findAll();
		model.addAttribute("listSP", listSP);
		return "index";
	}
	
	@GetMapping("/login")
	public String doGetLogin() {
		return "login";
	}
	
	@GetMapping("/logout")
	public String doGetLogout(HttpSession session) {
		session.removeAttribute("user");
		session.removeAttribute("cart");
		return "redirect:/index";
	}
	
	@PostMapping("/login")
	public String doPostLogin(@RequestParam("username") String username,
			@RequestParam("password") String password,
			HttpSession session) {
		User user = userService.checkLogin(username, password);
		if (user != null) {
			session.setAttribute("user", user);
			return "redirect:/index";
		}
		return "redirect:/login";
	}
}
