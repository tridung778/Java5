package com.fpoly.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fpoly.entity.SanPham;
import com.fpoly.repository.SanPhamRepo;

@Service
public class SanPhamService {
	
	@Autowired
	private SanPhamRepo repo;
	
	public List<SanPham> findAll() {
		return repo.findAll();
	}
	
	public List<SanPham> findByMaDM(String madm) {
		return repo.findByDanhmuc_Madm(madm);
	}
	
	public SanPham findByMaSP(String masp) {
		return repo.findByMasp(masp);
	}
	
	public void delete(String masp) {
		repo.deleteById(masp);
		
	}
	
	
	public void insertOrUpdate(SanPham sanpham) {
		repo.saveAndFlush(sanpham);
	}
}
