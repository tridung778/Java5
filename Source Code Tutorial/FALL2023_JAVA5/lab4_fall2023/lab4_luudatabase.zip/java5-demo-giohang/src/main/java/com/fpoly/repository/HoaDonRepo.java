package com.fpoly.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fpoly.entity.HoaDon;

public interface HoaDonRepo extends JpaRepository<HoaDon, Integer> {

}
