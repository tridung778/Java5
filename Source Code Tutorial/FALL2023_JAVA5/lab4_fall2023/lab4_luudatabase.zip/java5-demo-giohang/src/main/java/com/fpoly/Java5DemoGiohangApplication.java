package com.fpoly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java5DemoGiohangApplication {

	public static void main(String[] args) {
		SpringApplication.run(Java5DemoGiohangApplication.class, args);
	}

}
