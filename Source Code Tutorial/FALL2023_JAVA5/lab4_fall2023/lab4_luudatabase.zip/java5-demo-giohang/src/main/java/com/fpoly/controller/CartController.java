package com.fpoly.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fpoly.dto.CartDto;
import com.fpoly.entity.DanhMuc;
import com.fpoly.entity.User;
import com.fpoly.service.CartService;
import com.fpoly.service.DanhMucService;

@Controller
@RequestMapping("/cart")
public class CartController {
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private DanhMucService dmService;

	@GetMapping("/view")
	public String doGetViewCart(Model model) {
		List<DanhMuc> listDM = dmService.findAll();
		model.addAttribute("listDM", listDM);
		return "cart";
	}
	
	// localhost:8080/cart/add?maSP=...&soLuong=...&isUpdate=...
	@GetMapping("/add")
	public String doGetAddSP(@RequestParam("maSP") String masp,
			@RequestParam("soLuong") int soluong,
			@RequestParam("isUpdate") boolean isUpdate,
			Model model, HttpSession session) {
		CartDto cart = (CartDto) session.getAttribute("cart");
		// update Cart
		session.setAttribute("cart", cartService.updateCart(cart, masp, soluong, isUpdate));
		return "redirect:/cart/view";
	}
	
	// localhost:8080/cart/paynow?phone=...&address=...
	@GetMapping("/paynow")
	public String doGetPayNow(@RequestParam("phone") String phone,
			@RequestParam("address") String address,
			RedirectAttributes redirectAttributes, HttpSession session) {
		CartDto cart = (CartDto) session.getAttribute("cart");
		if (cart.getTongsl() == 0) {
			redirectAttributes.addFlashAttribute("error", "Giỏ hàng rỗng, vui lòng mua hàng");
			return "redirect:/cart/view";
		} else {
			User user = (User) session.getAttribute("user");
			cart.setUserId(user.getId());
			cart.setDiachi(address);
			cart.setDienthoai(phone);
			cartService.insertCart(cart);
			session.setAttribute("cart", new CartDto());
			redirectAttributes.addFlashAttribute("success", "Mua hàng thành công!!!");
			return "redirect:/index";
		}
	}
}
