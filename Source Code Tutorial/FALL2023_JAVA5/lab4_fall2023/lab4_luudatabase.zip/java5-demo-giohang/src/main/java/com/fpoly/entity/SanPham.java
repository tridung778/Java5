package com.fpoly.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "sanpham")
@NoArgsConstructor
@AllArgsConstructor
@Data
public class SanPham implements Serializable {

	private static final long serialVersionUID = -4510685623047026611L;

	@Id
	@Column(name = "masp")
	private String masp;
	
	@Column(name = "tensp")
	private String tensp;
	
	@Column(name = "giasp")
	private double giasp;
	
	@Column(name = "mota")
	private String mota;
	
	@Column(name = "soluong")
	private int soluong;
	
	@Column(name = "hinh")
	private String hinh;
	
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "madm", referencedColumnName = "madm")
	@JsonIgnoreProperties(value = {"applications", "hibernateLazyInitializer"})
	private DanhMuc danhmuc;
}
