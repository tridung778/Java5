package com.fpoly.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fpoly.entity.User;
import com.fpoly.repository.UserRepo;

@Service
public class UserService {

	@Autowired
	private UserRepo repo;
	
	public User checkLogin(String username, String password) {
		return repo.findByUsernameAndPassword(username, password);
	}
}
