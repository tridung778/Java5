package edu.poly.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import edu.poly.mail.MailerServiceImpl;
import edu.poly.model.MailInfo;
import javax.servlet.ServletContext;
import javax.servlet.annotation.MultipartConfig;

@Controller
@MultipartConfig
public class MailController {
	
	@Autowired
	MailerServiceImpl mailer;
	
	@Autowired
	ServletContext app;
	
	@GetMapping("/mail")
	public String mail(Model model, @ModelAttribute("mail") MailInfo mail) {
		return "mail";
	}
	
	@PostMapping("/mail/send")
	public String mail_send(Model model, @Validated @ModelAttribute("mail") MailInfo mail, BindingResult result, @RequestParam("files") MultipartFile[] files) {
		if(!result.hasErrors()) {
			if(!Arrays.asList(files).get(0).getOriginalFilename().equals("")) {
				String[] attachments = new String[files.length];
				int attachSize = -1;
				for(MultipartFile file:files) {
					String fileName = StringUtils.cleanPath(file.getOriginalFilename());
					attachSize++;
			        try {
			            Path path = Paths.get(app.getRealPath("/WEB-INF/upload/"+fileName));
			            Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
			            attachments[attachSize] = app.getRealPath("/WEB-INF/upload/"+fileName);
			            
			        } catch (IOException e) {
			            e.printStackTrace();
			        }
				}
				mail.setAttachments(attachments);
			}
			try {
				mailer.queue(mail);
				model.addAttribute("success_sendEmail", "Email sẽ được gửi trong giây lát!");
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return "mail";
	}
}
